# rsbotit
In this file you can find simple rsbots, which are made with robot.js. Bots are meant for studying in private servers. With these bots you will pretty surely get banned fast in normal runescape, so i suggest you not to try :D

Tässä kansiossa löytyy simppeleitä runebotteja, jotka ovat toteutettu robot.js:sällä. Botit tarkoitettu opiskelukäyttöön private servuilla. Näillä boteilla normirunessa saa aika nopeasti banhammeria niin ei kannata kokeilla :D
